class NadaNotAllowedException(Exception):
    pass
